<html>
	<head>
		<title>Admin Panel</title>
		<link rel="stylesheet" href="admin_style.css" />
	</head>
	
	<body>
			<div id="header"></div><!--end of header-->
	</body>
	
</html>