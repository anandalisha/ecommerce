<?php

	 
	$_COOKIE["user"]="";
	echo $_COOKIE["user"];

	
?>
<script type="text/javascript">

window.location="c_loginpage.php";
</script>