<div id="footer">
				<h3>copyright 2018 &copy  Type your name</h3>
				
				</div><!--end of footer-->