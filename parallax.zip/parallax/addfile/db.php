<?php

$con=new PDO("mysql:host=localhost;dbname=mydata","root","");
	//$server = "sql112.epizy.com";
	//$username = "epiz_26396808";
	//$password = "FG0aUMQVMKgG717";
	//$dbname = "epiz_26396808_mydata";

	//$conn = mysqli_connect("sql109.epizy.com", "TlvdhEi4NRTSL", "","epiz_26371767_mydata") or die('Database not Connected');

	//if(!$conn){
		//die("Connection Failed:".mysqli_connect_error());
	//}

?>