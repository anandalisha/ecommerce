
 <html>
 <head>
 <style>
 #bodyrightt{height:150%;width:25%;margin-top:7px; margin-left:10px; float:left;background:#fff;}


#bodyrightt h2{margin-top:15px;font-size:20px;text-shadow:5px 5px 5px #000; border-radius:4px;text-align:center; background:#400040;color:#fff;height:40px;line-height:40px;}


#bodyrighttt ul{list-style-type:none;}

#bodyrightt ul li{list-style-type:none;margin-left:0%;height:35px;width:100%;line-height:35px;margin-top:5px;}
#bodyrightt ul li{width:100%;height:120px; margin-top:5px;}
#bodyrightt ul li img{width:100%;height:120px; border-radius:1px;margin-top:5px;border:1px solid #fff;}
#bodyrightt ul li img:hover{border:1px solid #400040;}
</style>
</head>
<body>


	<div id="bodyrightt">
				
				
				<h2>Great Deals</h2>
					
					<ul>
						 
						<li ><a href="#"><img src="../addfile/c.jpg" /></a></li>
						<li ><a href="#"><img src="../addfile/b.jpg" /></a></li>
						<li ><a href="#"><img src="../imgs1/slider/4.jpg" /></a></li>
					
					</ul>
				
				</div><!--end of the bodyright--><br clear="all" />
				
	</body>
</html>	