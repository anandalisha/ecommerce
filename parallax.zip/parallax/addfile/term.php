<html>

<head>
<style>
*{margin:0%;}

</style>
</head>
<body>
		<?php include("header_demo.php");?>
		<img src="term.jpg" style="width:100%;height:267px;" />
	
		<img src="term1.jpg" style="width:100%;height:267px;" />
		
		<h3 style="margin-bottom:50px;">Offer Terms and Conditions</h3><br><br>
		<p style="margin-left:20px;margin-bottom:5px;">1.This offer ("Offer") is provided to you by ("MasterCard") and is made available to you on www.amazon.in or the mobile application / mobile site thereof (collectively, "Amazon.in") by Amazon Pay (India) Private Limited ("Amazon").</p>
		
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">2.All residents of India holding a valid and current MasterCard credit card or debit card (each a "Card") issued in India by any bank (each holder of a Card, "Cardholder").</p>
	
	
		<br><br><br><br>	<p style="margin-left:20px;margin-bottom:5px;">3.These Offer terms and conditions ("T&Cs") are in addition to the Amazon.in Conditions of Use & Sale and Privacy Notice to which you agree to by using Amazon.in. In the event of any conflict between the Conditions of Use & Sale and these T&Cs, these T&Cs will prevail, only for the purposes of this Offer.</p>
	
	
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">4.The Offer is valid from March 16, 2018 to May 15, 2018 (both days included) ("Offer Period"), unless extended or revoked without notice and without liability by MasterCard and/or Amazon, at their sole discretion.</p>
	
			<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">5.Under this Offer, the Parties agree that cashback will be provided to Cardholder who: </p>
	
	
		<br><br>	<p style="margin-left:50px;margin-bottom:5px;">(b) make a purchase on Amazon.in during the Offer Period; </p>
	
	
		<br><br><p style="margin-left:50px;margin-bottom:5px;">(c) chooses to pay for such purchase transaction using the Cash On Delivery ("CoD") payment method; and </p>
			<br><br>	<p style="margin-left:50px;margin-bottom:5px;">(d) elects to pay using any MasterCard credit card or debit card (each a "Card"), through (a) a card accepting machine carried by the delivery associate (mPOS machine) (b) the Amazon Pay Link (received through SMS or email) (c) a card accepting machine present in Udaan stores (Pay@store) </p>
	
	
		<br><br><br><br><p style="margin-left:50px;margin-bottom:5px;">Such transaction that fulfills all of the aforementioned criteria is referred as the "Transaction".</p>
				<br><br><br><br>	<p style="margin-left:20px;margin-bottom:15px;">6.To be eligible to avail the cashback in relation to the Transaction: 
(a) Cardholders should not have paid for a purchase on Amazon.in using the Card, (including use of the Card for a cash on delivery / CoD transaction) which is used to pay for the Transactions (or either of them) for a period of 12 months before the Offer Period (i.e. from March 16, 2017 to March 15, 2018); and 
(b) Cardholders should not have completed a purchase using any digital mode of payment (including net banking or other card networks or stored value accounts) from the Amazon.in account used to complete the Transactions during the aforementioned period of 12 months.</p>
	
	
		<br><br>	<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">7.For the avoidance of doubt: 
(a) in the event a Cardholder has completed only CoD transactions in the aforementioned preceding period of 12 months and the Cardholder uses a Card to pay for a CoD transaction through a card accepting machine during the Offer Period, such Cardholder will be entitled to the aforesaid cashback for the Transaction; 
(b) in the event a Cardholder has completed a transaction using digital mode of payment before the aforementioned preceding period of 12 months (i.e. before March 16, 2018), such Cardholder will be entitled to avail cashback for transactions completed in accordance with these Offer Terms; 
(c) cashback cannot be availed on Transaction completed using equated monthly installments.</p>
				<br><br>		<br><br><br><br>	<p style="margin-left:20px;margin-bottom:5px;">8.Cardholders who satisfy the criteria and conditions provided under these Offer Terms will be eligible to receive a cashback of an amount equivalent to 10% of the value of the Transaction, subject to a maximum cap of INR 100</p>
	
	
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">9.Such cashback will be credited: 
<br>(a) to the eligible Cardholder’s Amazon.in account using which the Transaction was completed; 
<br>(b) by way of Amazon Pay Balance.; and 
<br>(c) to the eligible Cardholder’s Amazon.in account as Amazon Pay Balance within 10 days of completion of the Transaction.</p>
				<br><br><br><br><br>	<p style="margin-left:20px;margin-bottom:5px;">10.The cashback will be provided to the eligible Cardholders in the form of Amazon Gift Card, issued by Quikcilver Solutions Private Limited ("Gift Card"). The use and redemption of the Amazon Gift Card is governed by the Amazon Gift Card Terms and Conditions available on Amazon.in.</p>
	
	
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">11.
Cardholders completing the Transaction using CoD and opting to pay for the Transaction: (i) in cash, or (ii) using any card other than the Card identified above (such as Visa, American Express, RuPay, Discover, Diners or any other credit card or debit card), are not eligible to receive the cashback under this Offer.</p>
				<br><br><br><br>	<p style="margin-left:20px;margin-bottom:5px;">12.
The Offer is not valid on purchase of products that are not eligible / available for payment through CoD ("Ineligible Products"). In the event a Transaction consists of multiple products including any Ineligible Product(s), this Offer can only be availed in relation to products under such Transaction other than the Ineligible Products.</p>
	
	
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">13.
In case the Cardholder either returns or refunds the product or cancels the Transaction or a Transaction is cancelled for any reason whatsoever, such Transaction will not qualify for the Offer. If the order is cancelled / returned in part, the Cardholder will qualify for the Offer only for the items in the order which are not cancelled / returned (subject to such items not being Ineligible Products).</p>
				<br><br><br><br>	<p style="margin-left:20px;margin-bottom:5px;">14.
Any disputes arising out of this Offer will be subject to the exclusive jurisdiction of the courts at New Delhi.</p>
	
	
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">15.
Cardholders are not bound in any manner to participate in the Offer. Any such participation is voluntary and the same is being made purely on a best effort basis.</p>
		
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">16.
Nothing herein amounts to a commitment by MasterCard or Amazon to conduct further, similar or other offers.</p>
		
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">17.
The above Offer is by way of a special offer and nothing contained herein shall prejudice or affect the terms and conditions of MasterCard Card member agreement between a Cardholder and the issuing bank.</p>
		
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">18.
By participating in this Offer, every customer (including a Cardholder) expressly agrees that Amazon and/or MasterCard or any of their affiliates will not be liable or responsible for any loss or damage whatsoever that customer may suffer, directly or indirectly, in connection with this Offer, including but not limited to that associated with his/her use or delivery or misuse of any product purchased on Amazon.in.</p>
		
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">19.
MasterCard and Amazon reserve the right, at any time, without prior notice and without assigning any reason whatsoever, to add/alter/modify/change or vary all of these terms and conditions or to replace, wholly or in part, this Offer by another offer, whether similar to this Offer or not, or to extend or withdraw it altogether.</p>
		
		
		<br><br><br><br><p style="margin-left:20px;margin-bottom:5px;">20.Any person availing this Offer will be deemed to have accepted these T&Cs.</p>
	
		
		<?php  include("backtotop.php");?>
		</body>
</html>