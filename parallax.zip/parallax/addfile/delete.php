<?php
include("function_user.php");

echo delete_cart_items();
?>