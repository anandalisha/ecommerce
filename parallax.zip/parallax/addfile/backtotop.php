<html>
<head>
<style>

#backtotop{width:100%;height:auto;background:#131A22;margin-top:20px;}

#backtotop h5{background:#232F3E;width:100%;height:50px;line-height:50px;text-align:center;color:#fff;cursor:pointer;}
#backtotop h5:hover{background:#708090;transition-duration: 3s;}

#backtotop table{width:75%;height:auto;margin-left:14%;margin-top:50px;color:#ffff;}

#backtotop table tr td{padding-left:34px;padding-top:15px;font-size:13px;}
#backtotop table tr td:hover{ text-decoration: underline;}
#footer{width:100%;height:40px;background:#400040;}
 #footer h3{line-height:40px;color:#fff;text-align:center;font-size:14px;text-shadow:5px 5px 5px #000;}
 #ragava{width:100%;height:40px;background:#232F3E;line-height:40px;color:#fff;text-align:center;font-size:14px;text-shadow:5px 5px 5px #000;}
 
</style>

</head>
<body>
<div id="backtotop">


<h5 onclick="topFunction()">Back to top</h5>

<table>
	
		<tr>
			<th><a href="downloadapp.php" style="text-decoration:none;font-size:13px;color:#ffff;">Get to Know Us</a></th>
			<th>Connect with Us</th>
			<th>Make Money with Us</th>
			
			<th>Let Us Help You</th>
		
		
		</tr>
		
		<tr>
		<td><a href="about.php" style="text-decoration:none;font-size:13px;color:#ffff;">About Us</a></td>
		<td><a href="index.php" style="text-decoration:none;font-size:13px;color:#ffff;">Facebook</a></td>
		<td style="padding-left:60px;">Sell </td>
		<td style="padding-left:100px;"><a href="your_account.php" style="text-decoration:none;color:#fff;">Your Account</a></td>
		
		</tr>
			<tr>
		<td>Careers</td>
		<td>Twitter</td>
		<td style="padding-left:60px;">Become an Affiliate</td>
		<td style="padding-left:100px;">Returns Centre</td>
		
		</tr>
			<tr>
		<td>Press Releases</td>
		<td>Instagram</td>
		<td style="padding-left:60px;">Fulfilment </td>
		<td style="padding-left:100px;">100% Purchase Protection</td>
		
		</tr>
		
			<tr>
		<td>Parallax Cares</td>
		<td></td>
		<td style="padding-left:60px;">Advertise Your Products</td>
		<td style="padding-left:100px;"> Assistant</td>
		
		</tr>
		
			<tr>
		<td>Gift a Smile</td>
		<td></td>
		<td style="padding-left:60px;"> Merchants</td>
		
		<td style="padding-left:100px;">Help</td>
		</tr>
	</table>
<hr style="border:0.3px solid #fff;margin-top:50px;opacity:0.2;">



</div>
<h3 id="ragava">copyright 2020 &copy  xxxx</h3>
<script>
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
	<div id="backtable">
	

	</div>




</body>
</html>