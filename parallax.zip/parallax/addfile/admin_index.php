<html>
	<head>
		<title>Admin Panel</title>
		<link rel="stylesheet" href="admin_style.css" />
	</head>
	<style>
				body{background:#400040;}
				
	</style>
	
	<body>
			
			
			<?php
			
				include("header.php");
				
				include("bodyleft.php");
			include("bodyright.php");
			
			
			?>
			
			
			
			
			
			
			
			
			
	</body>
	
</html>