<?php 


		function electronics()
		{
			include("db.php");
		}




?>