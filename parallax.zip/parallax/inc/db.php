<?php

	$con=new PDO("mysql:host=localhost;dbname=ragava","root","");

?>